const express = require('express');
const app = express();

app.use(express.json());

// Mock Log API endpoint
app.post('/api/log', (req, res) => {
  console.log('Received log:', req.body);
  res.status(200).json({ message: 'Log received successfully' });
});

const PORT = 3001;
app.listen(PORT, () => {
  console.log(`Mock Log API running on http://localhost:${PORT}`);
});