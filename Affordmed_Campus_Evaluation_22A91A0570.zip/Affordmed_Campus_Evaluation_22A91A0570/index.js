const express = require('express');
const axios = require('axios');

const app = express();
app.use(express.json());

const loggingMiddleware = async (req, res, next) => {
  try {
    const logData = {
      level: req.method === 'POST' ? 'info' : 'debug',
      message: `Request received: ${req.method} ${req.url}`,
      timestamp: new Date().toISOString(),
      path: req.url,
      method: req.method
    };

    const logApiUrl = 'http://localhost:3001/api/log'; 
    const response = await axios.post(logApiUrl, logData);

    if (response.status === 200) {
      console.log('Log sent successfully:', logData);
    } else {
      console.error('Failed to send log:', response.status);
    }
  } catch (error) {
    const errorLog = {
      level: 'error',
      message: `Logging failed: ${error.message}`,
      timestamp: new Date().toISOString(),
      path: req.url,
      method: req.method
    };
    console.error('Error in logging middleware:', errorLog);
  }
  next();
};

app.use(loggingMiddleware);

app.get('/', (req, res) => {
  res.send('Welcome to the Campus Hiring Evaluation Server!');
});

app.post('/register', (req, res) => {
  res.json({ message: 'User registered successfully!' });
});

const PORT = 3000;
app.listen(PORT, () => {
  console.log(`Server is running on http://localhost:${PORT}`);
});