from flask import Flask, request, jsonify, redirect
import hashlib
import base64
import sqlite3
from datetime import datetime

app = Flask(__name__)

conn = sqlite3.connect('urls.db', check_same_thread=False)  
cursor = conn.cursor()
cursor.execute('''CREATE TABLE IF NOT EXISTS urls
                 (short_code TEXT PRIMARY KEY, long_url TEXT, clicks INTEGER, last_accessed TEXT)''')
conn.commit() 

@app.route('/')
def home():
    return jsonify({
        "message": "Welcome to the URL Shortener Microservice",
        "endpoints": {
            "POST /shorten": "Create a short URL from a long URL",
            "GET /stats/<short_code>": "Retrieve statistics for a short URL",
            "GET /<short_code>": "Redirect to the original URL"
        }
    })

def generate_short_code(long_url):
    hash_object = hashlib.md5(long_url.encode())
    short_code = base64.urlsafe_b64encode(hash_object.digest()).decode()[:6]
    return short_code

@app.route('/shorten', methods=['POST'])
def create_short_url():
    data = request.get_json()  
    long_url = data.get('url') 
    if not long_url:
        return jsonify({"error": "URL is required"}), 400  
    
    if not long_url.startswith(('http://', 'https://')):
        return jsonify({"error": "Invalid URL format"}), 400
    
    short_code = generate_short_code(long_url)  
    cursor.execute("SELECT short_code FROM urls WHERE short_code = ?", (short_code,))
    if cursor.fetchone():  
        return jsonify({"error": "Short code collision, try again"}), 409
    

    cursor.execute("INSERT INTO urls (short_code, long_url, clicks, last_accessed) VALUES (?, ?, ?, ?)",
                  (short_code, long_url, 0, None))
    conn.commit()
    
    short_url = f"https://short.ly/{short_code}"
    return jsonify({"short_url": short_url}), 201  

@app.route('/stats/<short_code>', methods=['GET'])
def get_stats(short_code):
    cursor.execute("SELECT long_url, clicks, last_accessed FROM urls WHERE short_code = ?", (short_code,))
    result = cursor.fetchone()
    if not result:
        return jsonify({"error": "Short URL not found"}), 404  
    
    long_url, clicks, last_accessed = result
    return jsonify({
        "short_url": f"https://short.ly/{short_code}",
        "long_url": long_url,
        "clicks": clicks,
        "last_accessed": last_accessed
    })

@app.route('/<short_code>')
def redirect_url(short_code):
    cursor.execute("SELECT long_url, clicks, last_accessed FROM urls WHERE short_code = ?", (short_code,))
    result = cursor.fetchone()
    if not result:
        return jsonify({"error": "Short URL not found"}), 404
    
    long_url, clicks, _ = result
    cursor.execute("UPDATE urls SET clicks = ?, last_accessed = ? WHERE short_code = ?",
                  (clicks + 1, datetime.utcnow().isoformat(), short_code))
    conn.commit()
    return redirect(long_url, code=302)  

if __name__ == '__main__':
    app.run(debug=True)  